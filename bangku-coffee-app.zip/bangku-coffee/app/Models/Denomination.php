<?php

namespace App\Models;

use App\Models\Concerns\Audited;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/** Pecahan uang kertas yang dihitung per lembar saat buka/tutup shift. */
#[Fillable(['value', 'is_active', 'sort'])]
class Denomination extends Model
{
    use Audited;

    protected function casts(): array
    {
        return ['value' => 'integer', 'is_active' => 'boolean'];
    }

    public function scopeActive(Builder $query): void
    {
        $query->where('is_active', true)->orderBy('sort');
    }
}
